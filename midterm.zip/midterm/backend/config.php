<?php
// XAMPP defaults. Change if your MySQL uses a password.
$pdo = new PDO("mysql:host=localhost;dbname=midterm_db;charset=utf8mb4", "root", "", [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);
