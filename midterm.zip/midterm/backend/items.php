<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }

require 'config.php';
$method = $_SERVER['REQUEST_METHOD'];
$in = json_decode(file_get_contents('php://input'), true) ?? [];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

function out($data, $code = 200) { http_response_code($code); echo json_encode($data); exit; }

function validate($in) {
    $name = trim($in['name'] ?? ''); $cat = trim($in['category'] ?? '');
    if (strlen($name) < 2) out(['success'=>false,'message'=>'Name must be at least 2 characters'], 422);
    if ($cat === '')       out(['success'=>false,'message'=>'Category is required'], 422);
    return [$name, $cat, trim($in['description'] ?? '')];
}

try {
    switch ($method) {
        case 'GET':
            if ($id) {
                $s = $pdo->prepare("SELECT id,name,category,description FROM items WHERE id=?");
                $s->execute([$id]); $row = $s->fetch();
                $row ? out($row) : out(['success'=>false,'message'=>'Not found'], 404);
            }
            out($pdo->query("SELECT id,name,category,description FROM items ORDER BY id DESC")->fetchAll());
        case 'POST':
            [$n,$c,$d] = validate($in);
            $pdo->prepare("INSERT INTO items(name,category,description) VALUES(?,?,?)")->execute([$n,$c,$d]);
            out(['success'=>true,'message'=>'Created','id'=>(int)$pdo->lastInsertId()], 201);
        case 'PUT':
            if (!$id) out(['success'=>false,'message'=>'id required'], 400);
            [$n,$c,$d] = validate($in);
            $pdo->prepare("UPDATE items SET name=?,category=?,description=? WHERE id=?")->execute([$n,$c,$d,$id]);
            out(['success'=>true,'message'=>'Updated']);
        case 'DELETE':
            if (!$id) out(['success'=>false,'message'=>'id required'], 400);
            $pdo->prepare("DELETE FROM items WHERE id=?")->execute([$id]);
            out(['success'=>true,'message'=>'Deleted']);
        default:
            out(['success'=>false,'message'=>'Method not allowed'], 405);
    }
} catch (Exception $e) {
    out(['success'=>false,'message'=>'Server error'], 500);
}
