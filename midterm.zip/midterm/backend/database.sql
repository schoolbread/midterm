CREATE DATABASE IF NOT EXISTS midterm_db;
USE midterm_db;
CREATE TABLE IF NOT EXISTS items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  category VARCHAR(50) NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO items (name, category, description) VALUES
('Sample One','General','First sample record'),
('Sample Two','General','Second sample record');
