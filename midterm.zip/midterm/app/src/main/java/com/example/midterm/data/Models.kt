package com.example.midterm.data

// Your custom API entity (rename to match your assigned topic)
data class Item(
    val id: Int = 0,
    val name: String,
    val category: String,
    val description: String = ""
)

data class ApiResponse(val success: Boolean, val message: String?)

// ZenQuotes returns: [{"q":"quote text","a":"author","h":"..."}]
data class Quote(val q: String, val a: String)
