package com.example.midterm.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.midterm.data.Item
import com.example.midterm.data.Network
import com.example.midterm.data.Quote
import kotlinx.coroutines.launch

class ItemViewModel : ViewModel() {
    var items by mutableStateOf<List<Item>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    var quote by mutableStateOf<Quote?>(null); private set
    var quoteError by mutableStateOf(false); private set

    init { loadItems(); loadQuote() }

    // READ
    fun loadItems() = viewModelScope.launch {
        loading = true; error = null
        try { items = Network.items.getItems() }
        catch (e: Exception) { error = "Could not load items: ${e.message}" }
        loading = false
    }

    // EXTERNAL API
    fun loadQuote() = viewModelScope.launch {
        quoteError = false
        try { quote = Network.quotes.random().firstOrNull() }
        catch (e: Exception) { quoteError = true }
    }

    // CREATE or UPDATE (id == 0 means create)
    fun save(item: Item, onDone: () -> Unit) = viewModelScope.launch {
        try {
            val r = if (item.id == 0) Network.items.create(item)
                    else Network.items.update(item.id, item)
            if (r.success) { loadItems(); onDone() } else error = r.message
        } catch (e: Exception) { error = "Save failed: ${e.message}" }
    }

    // DELETE
    fun delete(id: Int, onDone: () -> Unit) = viewModelScope.launch {
        try {
            val r = Network.items.delete(id)
            if (r.success) { loadItems(); onDone() } else error = r.message
        } catch (e: Exception) { error = "Delete failed: ${e.message}" }
    }

    fun clearError() { error = null }
}
