package com.example.midterm.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.dp
import com.example.midterm.data.Item

// ---------- Daily quote banner (External API) ----------
@Composable
fun QuoteBanner(vm: ItemViewModel) {
    Card(
        Modifier.fillMaxWidth().padding(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("Quote of the moment", style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(6.dp))
            val q = vm.quote
            when {
                q != null -> {
                    Text("\u201C${q.q}\u201D", style = MaterialTheme.typography.bodyLarge, fontStyle = FontStyle.Italic)
                    Text("\u2014 ${q.a}", style = MaterialTheme.typography.bodySmall)
                }
                vm.quoteError -> Text("Couldn't load quote.")
                else -> LinearProgressIndicator(Modifier.fillMaxWidth())
            }
            TextButton(onClick = { vm.loadQuote() }) { Text("New quote") }
        }
    }
}

// ---------- READ: list ----------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListScreen(vm: ItemViewModel, onOpen: (Int) -> Unit, onAdd: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("My Records") }, actions = {
                IconButton(onClick = { vm.loadItems() }) { Icon(Icons.Default.Refresh, "Refresh") }
            })
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAdd) { Icon(Icons.Default.Add, "Add") }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize()) {
            item { QuoteBanner(vm) }
            if (vm.loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
            vm.error?.let { e -> item { Text(e, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp)) } }
            if (!vm.loading && vm.items.isEmpty() && vm.error == null)
                item { Text("No records yet. Tap + to add one.", modifier = Modifier.padding(16.dp)) }
            items(vm.items, key = { it.id }) { item ->
                Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
                    .clickable { onOpen(item.id) }) {
                    Column(Modifier.padding(16.dp)) {
                        Text(item.name, style = MaterialTheme.typography.titleMedium)
                        Text(item.category, style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

// ---------- Detail + DELETE confirmation ----------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(vm: ItemViewModel, id: Int, onBack: () -> Unit, onEdit: (Int) -> Unit) {
    val item = vm.items.find { it.id == id }
    var confirm by remember { mutableStateOf(false) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Details") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            actions = {
                if (item != null) {
                    IconButton(onClick = { onEdit(id) }) { Icon(Icons.Default.Edit, "Edit") }
                    IconButton(onClick = { confirm = true }) { Icon(Icons.Default.Delete, "Delete") }
                }
            })
    }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            if (item == null) Text("Record not found.") else {
                Text(item.name, style = MaterialTheme.typography.headlineSmall)
                Text(item.category, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(12.dp))
                Text(item.description.ifBlank { "No description." })
            }
        }
    }

    if (confirm && item != null) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Delete record?") },
            text = { Text("\"${item.name}\" will be permanently removed.") },
            confirmButton = {
                TextButton(onClick = { confirm = false; vm.delete(id, onBack) }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
        )
    }
}

// ---------- CREATE / UPDATE form with validation ----------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FormScreen(vm: ItemViewModel, id: Int, onDone: () -> Unit) {
    val existing = vm.items.find { it.id == id }          // null when creating
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var category by remember { mutableStateOf(existing?.category ?: "") }
    var desc by remember { mutableStateOf(existing?.description ?: "") }
    var submitted by remember { mutableStateOf(false) }

    val nameErr = if (name.trim().length < 2) "Name must be at least 2 characters" else null
    val catErr = if (category.isBlank()) "Category is required" else null

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(if (id == 0) "Add Record" else "Edit Record") },
            navigationIcon = { IconButton(onClick = onDone) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } })
    }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth(),
                isError = submitted && nameErr != null, supportingText = { if (submitted) nameErr?.let { Text(it) } })
            OutlinedTextField(category, { category = it }, label = { Text("Category") }, modifier = Modifier.fillMaxWidth(),
                isError = submitted && catErr != null, supportingText = { if (submitted) catErr?.let { Text(it) } })
            OutlinedTextField(desc, { desc = it }, label = { Text("Description") },
                modifier = Modifier.fillMaxWidth(), minLines = 3)
            vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(modifier = Modifier.fillMaxWidth(), onClick = {
                submitted = true
                if (nameErr == null && catErr == null) {
                    vm.clearError()
                    vm.save(Item(id, name.trim(), category.trim(), desc.trim()), onDone)
                }
            }) { Text(if (id == 0) "Save" else "Update") }
        }
    }
}
